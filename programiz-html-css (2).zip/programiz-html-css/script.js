// Backend Database Simulation using localStorage
const NeuroSyncDB = {
    // Initialize database
    init: function() {
        if (!localStorage.getItem('neurosync_children')) {
            localStorage.setItem('neurosync_children', JSON.stringify([]));
        }
        if (!localStorage.getItem('neurosync_reports')) {
            localStorage.setItem('neurosync_reports', JSON.stringify([]));
        }
        if (!localStorage.getItem('neurosync_current_child')) {
            localStorage.setItem('neurosync_current_child', JSON.stringify(null));
        }
        if (!localStorage.getItem('neurosync_settings')) {
            localStorage.setItem('neurosync_settings', JSON.stringify({
                reminders: true,
                updates: true,
                camera: true
            }));
        }
    },
    
    // Child management
    addChild: function(childData) {
        const children = JSON.parse(localStorage.getItem('neurosync_children'));
        const childId = Date.now().toString();
        childData.id = childId;
        childData.createdAt = new Date().toISOString();
        children.push(childData);
        localStorage.setItem('neurosync_children', JSON.stringify(children));
        localStorage.setItem('neurosync_current_child', JSON.stringify(childData));
        return childData;
    },
    
    getCurrentChild: function() {
        return JSON.parse(localStorage.getItem('neurosync_current_child'));
    },
    
    updateChild: function(childData) {
        const children = JSON.parse(localStorage.getItem('neurosync_children'));
        const index = children.findIndex(c => c.id === childData.id);
        if (index !== -1) {
            children[index] = childData;
            localStorage.setItem('neurosync_children', JSON.stringify(children));
            localStorage.setItem('neurosync_current_child', JSON.stringify(childData));
            return true;
        }
        return false;
    },
    
    getAllChildren: function() {
        return JSON.parse(localStorage.getItem('neurosync_children'));
    },
    
    deleteChild: function(childId) {
        const children = JSON.parse(localStorage.getItem('neurosync_children'));
        const filtered = children.filter(c => c.id !== childId);
        localStorage.setItem('neurosync_children', JSON.stringify(filtered));
        
        // If deleted child was current, set current to null
        const current = this.getCurrentChild();
        if (current && current.id === childId) {
            localStorage.setItem('neurosync_current_child', JSON.stringify(null));
        }
        return true;
    },
    
    // Report management
    addReport: function(reportData) {
        const reports = JSON.parse(localStorage.getItem('neurosync_reports'));
        reportData.id = Date.now().toString();
        reportData.createdAt = new Date().toISOString();
        reports.push(reportData);
        localStorage.setItem('neurosync_reports', JSON.stringify(reports));
        return reportData;
    },
    
    getReportsByChild: function(childId) {
        const reports = JSON.parse(localStorage.getItem('neurosync_reports'));
        return reports.filter(r => r.childId === childId).sort((a, b) => 
            new Date(b.createdAt) - new Date(a.createdAt)
        );
    },
    
    getAllReports: function() {
        const reports = JSON.parse(localStorage.getItem('neurosync_reports'));
        return reports.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    
    deleteReport: function(reportId) {
        const reports = JSON.parse(localStorage.getItem('neurosync_reports'));
        const filtered = reports.filter(r => r.id !== reportId);
        localStorage.setItem('neurosync_reports', JSON.stringify(filtered));
        return true;
    },
    
    // Settings management
    getSettings: function() {
        return JSON.parse(localStorage.getItem('neurosync_settings'));
    },
    
    updateSettings: function(settings) {
        localStorage.setItem('neurosync_settings', JSON.stringify(settings));
        return true;
    },
    
    // Data export/import
    exportData: function() {
        const data = {
            children: JSON.parse(localStorage.getItem('neurosync_children')),
            reports: JSON.parse(localStorage.getItem('neurosync_reports')),
            settings: JSON.parse(localStorage.getItem('neurosync_settings')),
            exportDate: new Date().toISOString()
        };
        return JSON.stringify(data, null, 2);
    },
    
    importData: function(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            if (data.children) localStorage.setItem('neurosync_children', JSON.stringify(data.children));
            if (data.reports) localStorage.setItem('neurosync_reports', JSON.stringify(data.reports));
            if (data.settings) localStorage.setItem('neurosync_settings', JSON.stringify(data.settings));
            return true;
        } catch (error) {
            console.error('Import failed:', error);
            return false;
        }
    },
    
    clearAllData: function() {
        localStorage.removeItem('neurosync_children');
        localStorage.removeItem('neurosync_reports');
        localStorage.removeItem('neurosync_current_child');
        localStorage.removeItem('neurosync_settings');
        this.init();
        return true;
    }
};

// Initialize database on load
NeuroSyncDB.init();

// Global variables
let currentAssessment = {
    childId: '',
    childName: '',
    childAge: '',
    startTime: null,
    endTime: null,
    riskLevel: 'low',
    riskPercentage: 0,
    totalScore: 0,
    maxScore: 0,
    categories: {
        socialAttention: { score: 0, max: 10 },
        emotionRecognition: { score: 0, max: 6 }
    },
    recommendations: '',
    specialists: []
};

// Game variables
let emotionQuestions = [
    { emotion: 'happy', emoji: '😊', difficulty: 1 },
    { emotion: 'sad', emoji: '😢', difficulty: 1 },
    { emotion: 'angry', emoji: '😠', difficulty: 2 },
    { emotion: 'surprised', emoji: '😲', difficulty: 2 },
    { emotion: 'scared', emoji: '😨', difficulty: 3 },
    { emotion: 'tired', emoji: '😴', difficulty: 3 }
];

let currentQuestionIndex = 0;
let emotionScore = 0;
let gazeScore = 0;

// Screen navigation
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
    
    // Update navigation active state
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Update UI based on screen
    switch(screenId) {
        case 'dashboard-screen':
            updateDashboard();
            break;
        case 'reports-screen':
            showAllReports();
            break;
        case 'settings-screen':
            updateSettingsScreen();
            break;
        case 'consent-screen':
            updateConsentScreen();
            break;
    }
}

// Child Info Functions
function setupChildInfoListeners() {
    const privacyCheckbox = document.getElementById('privacy-consent');
    const startBtn = document.getElementById('start-assessment-btn');
    
    privacyCheckbox.addEventListener('change', function() {
        startBtn.disabled = !this.checked;
    });
}

function startAssessment() {
    const childName = document.getElementById('child-name').value.trim();
    const childAge = document.getElementById('child-age').value;
    
    if (!childName || !childAge) {
        alert('Please enter child\'s name and age');
        return;
    }
    
    const childData = {
        name: childName,
        age: childAge,
        gender: document.getElementById('child-gender').value,
        parentName: document.getElementById('parent-name').value.trim(),
        createdAt: new Date().toISOString()
    };
    
    const savedChild = NeuroSyncDB.addChild(childData);
    
    // Initialize assessment
    currentAssessment.childId = savedChild.id;
    currentAssessment.childName = savedChild.name;
    currentAssessment.childAge = savedChild.age;
    currentAssessment.startTime = new Date().toISOString();
    
    showScreen('consent-screen');
}

// Consent Functions
function updateConsentScreen() {
    const child = NeuroSyncDB.getCurrentChild();
    if (!child) {
        showScreen('child-info-screen');
        return;
    }
    
    const summaryDiv = document.getElementById('child-info-summary');
    summaryDiv.innerHTML = `
        <div class="child-info-avatar">
            <i class="fas fa-child"></i>
        </div>
        <div class="child-info-text">
            <h4>${child.name}</h4>
            <p>Age: ${child.age} months | Screening Date: ${new Date().toLocaleDateString()}</p>
        </div>
    `;
}

function setupConsentListeners() {
    const consentCheckbox = document.getElementById('consent-checkbox');
    const cameraCheckbox = document.getElementById('camera-consent');
    const consentBtn = document.getElementById('consent-btn');
    
    function updateConsentButton() {
        consentBtn.disabled = !(consentCheckbox.checked && cameraCheckbox.checked);
    }
    
    consentCheckbox.addEventListener('change', updateConsentButton);
    cameraCheckbox.addEventListener('change', updateConsentButton);
}

function validateConsent() {
    showScreen('game1-screen');
}

// Game 1: Social Attention
function startGame1() {
    document.getElementById('start-game1-btn').style.display = 'none';
    
    // Initialize gaze tracking score
    gazeScore = 0;
    
    // Show targets with delay to simulate gaze tracking
    const target1 = document.getElementById('target1');
    const target2 = document.getElementById('target2');
    
    // Sequence 1: Target 1 appears
    setTimeout(() => {
        target1.classList.add('active');
        // Simulate child looking at target
        setTimeout(() => {
            if (Math.random() > 0.3) gazeScore += 3; // Random success
        }, 1000);
    }, 1000);
    
    // Sequence 2: Target 1 disappears, Target 2 appears
    setTimeout(() => {
        target1.classList.remove('active');
        target2.classList.add('active');
        setTimeout(() => {
            if (Math.random() > 0.4) gazeScore += 3;
        }, 1000);
    }, 4000);
    
    // Sequence 3: Both targets appear
    setTimeout(() => {
        target1.classList.add('active');
        setTimeout(() => {
            if (Math.random() > 0.5) gazeScore += 4;
        }, 1000);
    }, 7000);
    
    // End game after 45 seconds
    setTimeout(() => {
        finishGame1();
    }, 45000);
    
    // Timer
    let timeLeft = 45;
    const timerElement = document.getElementById('timer1');
    const progressElement = document.getElementById('game1-progress');
    
    const timer = setInterval(() => {
        timeLeft--;
        timerElement.textContent = `Time: ${timeLeft}s`;
        progressElement.style.width = `${((45 - timeLeft) / 45) * 100}%`;
        
        if (timeLeft <= 0) {
            clearInterval(timer);
        }
    }, 1000);
}

function finishGame1() {
    currentAssessment.categories.socialAttention.score = Math.min(gazeScore, 10);
    showScreen('game2-screen');
    startGame2();
}

// Game 2: Emotion Recognition
function startGame2() {
    currentQuestionIndex = 0;
    emotionScore = 0;
    showEmotionQuestion();
}

function showEmotionQuestion() {
    if (currentQuestionIndex >= emotionQuestions.length) {
        finishGame2();
        return;
    }
    
    const question = emotionQuestions[currentQuestionIndex];
    const emotionCharacter = document.getElementById('emotion-character');
    const currentQuestionElement = document.getElementById('current-question');
    const totalQuestionsElement = document.getElementById('total-questions');
    const progressElement = document.getElementById('game2-progress');
    const scoreElement = document.getElementById('emotion-score');
    
    emotionCharacter.textContent = question.emoji;
    emotionCharacter.style.animation = 'pulse 0.5s ease';
    
    currentQuestionElement.textContent = currentQuestionIndex + 1;
    totalQuestionsElement.textContent = emotionQuestions.length;
    progressElement.style.width = `${((currentQuestionIndex + 1) / emotionQuestions.length) * 100}%`;
    scoreElement.textContent = `Score: ${emotionScore}/${currentQuestionIndex}`;
    
    // Remove animation after it completes
    setTimeout(() => {
        emotionCharacter.style.animation = '';
    }, 500);
}

function selectEmotion(selectedEmotion) {
    const question = emotionQuestions[currentQuestionIndex];
    
    // Check if selected emotion matches
    if (selectedEmotion === question.emotion) {
        emotionScore += question.difficulty;
        // Visual feedback for correct answer
        document.getElementById('emotion-character').style.color = '#28a745';
    } else {
        // Visual feedback for incorrect answer
        document.getElementById('emotion-character').style.color = '#dc3545';
    }
    
    currentQuestionIndex++;
    
    // Reset color and show next question
    setTimeout(() => {
        document.getElementById('emotion-character').style.color = '';
        showEmotionQuestion();
    }, 500);
}

function finishGame2() {
    currentAssessment.categories.emotionRecognition.score = emotionScore;
    currentAssessment.totalScore = currentAssessment.categories.socialAttention.score + emotionScore;
    currentAssessment.maxScore = 16; // 10 from social + 6 from emotion
    
    calculateRiskAssessment();
    showScreen('results-screen');
    displayResults();
}

// Risk Assessment Calculation
function calculateRiskAssessment() {
    const totalScore = currentAssessment.totalScore;
    const maxScore = currentAssessment.maxScore;
    const percentage = (totalScore / maxScore) * 100;
    
    currentAssessment.riskPercentage = Math.round(percentage);
    
    if (percentage >= 80) {
        currentAssessment.riskLevel = 'low';
        currentAssessment.recommendations = 'Based on this screening, your child\'s responses appear to be within typical developmental ranges. We recommend routine developmental monitoring and follow-up screening in 6 months.';
        currentAssessment.specialists = [];
    } else if (percentage >= 60) {
        currentAssessment.riskLevel = 'medium';
        currentAssessment.recommendations = 'Based on this screening, your child shows some subtle markers that may benefit from further observation. We recommend discussing these results with your pediatrician and considering a follow-up assessment in 3 months.';
        currentAssessment.specialists = [
            { name: 'Pediatrician', specialty: 'General Checkup', location: 'Local Clinic' }
        ];
    } else {
        currentAssessment.riskLevel = 'high';
        currentAssessment.recommendations = 'Based on this screening, your child shows markers that would benefit from further evaluation. We recommend consulting with a child development specialist for a comprehensive assessment. Early intervention can make a significant difference.';
        currentAssessment.specialists = [
            { name: 'Dr. Priya Sharma', specialty: 'Developmental Pediatrician', location: 'New Delhi' },
            { name: 'Dr. Arjun Mehta', specialty: 'Child Psychologist', location: 'Mumbai' },
            { name: 'Dr. Anjali Reddy', specialty: 'Pediatric Neurologist', location: 'Bangalore' }
        ];
    }
    
    currentAssessment.endTime = new Date().toISOString();
}

// Results Display
function displayResults() {
    const child = NeuroSyncDB.getCurrentChild();
    
    // Update child info
    document.getElementById('results-child-name').textContent = child.name;
    document.getElementById('results-child-age').textContent = `Age: ${child.age} months`;
    document.getElementById('results-date').textContent = `Date: ${new Date().toLocaleDateString()}`;
    
    // Update risk indicator
    const riskIndicator = document.getElementById('risk-indicator-large');
    const riskCircle = riskIndicator.querySelector('.risk-circle');
    const riskLabel = riskIndicator.querySelector('.risk-label');
    const riskPercentage = document.getElementById('risk-percentage');
    
    riskCircle.style.background = getRiskColor(currentAssessment.riskLevel);
    riskPercentage.textContent = `${currentAssessment.riskPercentage}%`;
    riskLabel.textContent = currentAssessment.riskLevel.charAt(0).toUpperCase() + currentAssessment.riskLevel.slice(1) + ' Risk';
    
    // Update scores
    document.getElementById('total-score').textContent = currentAssessment.totalScore;
    document.getElementById('max-score').textContent = currentAssessment.maxScore;
    document.getElementById('accuracy').textContent = `${Math.round((currentAssessment.totalScore / currentAssessment.maxScore) * 100)}%`;
    
    // Update category scores
    document.getElementById('social-score').textContent = 
        `${currentAssessment.categories.socialAttention.score}/${currentAssessment.categories.socialAttention.max}`;
    document.getElementById('emotion-result-score').textContent = 
        `${currentAssessment.categories.emotionRecognition.score}/${currentAssessment.categories.emotionRecognition.max}`;
    
    // Update progress bars
    document.getElementById('social-progress').style.width = 
        `${(currentAssessment.categories.socialAttention.score / currentAssessment.categories.socialAttention.max) * 100}%`;
    document.getElementById('emotion-progress').style.width = 
        `${(currentAssessment.categories.emotionRecognition.score / currentAssessment.categories.emotionRecognition.max) * 100}%`;
    
    // Update recommendations
    document.getElementById('recommendation-box').innerHTML = 
        `<p>${currentAssessment.recommendations}</p>`;
    
    // Update specialists
    const specialistList = document.getElementById('specialist-list');
    const specialistSection = document.getElementById('specialist-section');
    
    if (currentAssessment.specialists.length > 0) {
        specialistSection.style.display = 'block';
        specialistList.innerHTML = currentAssessment.specialists.map(spec => `
            <div class="specialist">
                <div class="specialist-name">${spec.name}</div>
                <div class="specialist-specialty">${spec.specialty}</div>
                <div class="specialist-location">${spec.location}</div>
            </div>
        `).join('');
    } else {
        specialistSection.style.display = 'none';
    }
}

function getRiskColor(riskLevel) {
    switch(riskLevel) {
        case 'low': return 'linear-gradient(135deg, #28a745, #20c997)';
        case 'medium': return 'linear-gradient(135deg, #ffc107, #fd7e14)';
        case 'high': return 'linear-gradient(135deg, #dc3545, #c82333)';
        default: return 'linear-gradient(135deg, #6c757d, #495057)';
    }
}

// Save Report
function saveReport() {
    const child = NeuroSyncDB.getCurrentChild();
    
    const reportData = {
        childId: child.id,
        childName: child.name,
        childAge: child.age,
        date: new Date().toISOString(),
        riskLevel: currentAssessment.riskLevel,
        riskPercentage: currentAssessment.riskPercentage,
        totalScore: currentAssessment.totalScore,
        maxScore: currentAssessment.maxScore,
        categories: currentAssessment.categories,
        recommendations: currentAssessment.recommendations,
        specialists: currentAssessment.specialists
    };
    
    NeuroSyncDB.addReport(reportData);
    
    alert('Report saved successfully!');
    showScreen('dashboard-screen');
}

// Dashboard Functions
function updateDashboard() {
    const child = NeuroSyncDB.getCurrentChild();
    const currentChildInfo = document.getElementById('current-child-info');
    const reportsList = document.getElementById('dashboard-reports-list');
    
    // Update current child info
    if (child) {
        currentChildInfo.innerHTML = `
            <div class="child-profile-display">
                <div class="child-avatar">
                    <i class="fas fa-child"></i>
                </div>
                <div class="child-details">
                    <h3>${child.name}</h3>
                    <p>Age: ${child.age} months | ${child.gender ? `Gender: ${child.gender}` : ''}</p>
                    ${child.parentName ? `<p>Parent: ${child.parentName}</p>` : ''}
                </div>
            </div>
        `;
    } else {
        currentChildInfo.innerHTML = `
            <div class="child-profile-display">
                <div class="child-avatar">
                    <i class="fas fa-user-plus"></i>
                </div>
                <div class="child-details">
                    <h3>No Child Profile</h3>
                    <p>Add a child profile to start screening</p>
                </div>
            </div>
        `;
    }
    
    // Update recent reports
    const reports = child ? NeuroSyncDB.getReportsByChild(child.id) : [];
    reportsList.innerHTML = '';
    
    if (reports.length === 0) {
        reportsList.innerHTML = `
            <div class="report-item">
                <div class="report-date">No assessments yet</div>
                <div class="report-risk risk-low">Start Now</div>
            </div>
        `;
    } else {
        reports.slice(0, 3).forEach(report => {
            const reportDate = new Date(report.date).toLocaleDateString();
            const reportItem = document.createElement('div');
            reportItem.className = 'report-item';
            reportItem.innerHTML = `
                <div class="report-date">${reportDate}</div>
                <div class="report-risk risk-${report.riskLevel}">${report.riskLevel.toUpperCase()}</div>
            `;
            reportsList.appendChild(reportItem);
        });
    }
}

// Reports Screen
function showAllReports() {
    const reportsContainer = document.getElementById('reports-container');
    const reports = NeuroSyncDB.getAllReports();
    
    reportsContainer.innerHTML = '';
    
    if (reports.length === 0) {
        reportsContainer.innerHTML = `
            <div class="report-card">
                <div class="report-header">
                    <div class="report-child-info">
                        <h4>No Reports Yet</h4>
                        <p>Complete your first assessment to see reports here</p>
                    </div>
                </div>
            </div>
        `;
        return;
    }
    
    reports.forEach(report => {
        const reportDate = new Date(report.date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
        
        const reportCard = document.createElement('div');
        reportCard.className = 'report-card fade-in';
        reportCard.innerHTML = `
            <div class="report-header">
                <div class="report-child-info">
                    <h4>${report.childName}</h4>
                    <p>Age: ${report.childAge} months | ${reportDate}</p>
                </div>
                <div class="report-risk-badge risk-${report.riskLevel}">
                    ${report.riskLevel.toUpperCase()}
                </div>
            </div>
            <div class="report-details">
                <div class="report-score">
                    <span>Total Score:</span>
                    <span><strong>${report.totalScore}/${report.maxScore}</strong></span>
                </div>
                <div class="report-score">
                    <span>Risk Level:</span>
                    <span><strong>${report.riskPercentage}% (${report.riskLevel})</strong></span>
                </div>
                <div class="report-recommendation">
                    ${report.recommendations.substring(0, 100)}...
                </div>
            </div>
        `;
        
        reportsContainer.appendChild(reportCard);
    });
}

// Settings Screen
function updateSettingsScreen() {
    const child = NeuroSyncDB.getCurrentChild();
    const currentProfile = document.getElementById('current-profile');
    const settings = NeuroSyncDB.getSettings();
    
    // Update current profile
    if (child) {
        currentProfile.innerHTML = `
            <div class="profile-display">
                <div class="profile-avatar">
                    <i class="fas fa-child"></i>
                </div>
                <div class="profile-info">
                    <h5>${child.name}</h5>
                    <p>Age: ${child.age} months</p>
                    <p>Added: ${new Date(child.createdAt).toLocaleDateString()}</p>
                </div>
            </div>
        `;
    } else {
        currentProfile.innerHTML = `
            <div class="profile-display">
                <div class="profile-avatar">
                    <i class="fas fa-user-plus"></i>
                </div>
                <div class="profile-info">
                    <h5>No Child Profile</h5>
                    <p>Add a child profile to start screening</p>
                </div>
            </div>
        `;
    }
    
    // Update settings toggles
    document.getElementById('reminder-toggle').checked = settings.reminders;
    document.getElementById('update-toggle').checked = settings.updates;
    
    // Add event listeners to toggles
    document.getElementById('reminder-toggle').addEventListener('change', function() {
        settings.reminders = this.checked;
        NeuroSyncDB.updateSettings(settings);
    });
    
    document.getElementById('update-toggle').addEventListener('change', function() {
        settings.updates = this.checked;
        NeuroSyncDB.updateSettings(settings);
    });
}

// Data Management Functions
function exportData() {
    const data = NeuroSyncDB.exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `neurosync-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    alert('Data exported successfully!');
}

function clearData() {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
        NeuroSyncDB.clearAllData();
        alert('All data has been cleared.');
        showScreen('welcome-screen');
    }
}

// Initialize the app
window.onload = function() {
    // Setup event listeners
    setupChildInfoListeners();
    setupConsentListeners();
    
    // Check if we have a current child
    const child = NeuroSyncDB.getCurrentChild();
    if (child) {
        showScreen('dashboard-screen');
    } else {
        showScreen('welcome-screen');
    }
    
    // Add click handlers for resource buttons
    document.querySelectorAll('.resource-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            alert('In a real application, this would open the corresponding resource section.');
        });
    });
    
    // Initialize settings screen if needed
    const settings = NeuroSyncDB.getSettings();
    if (!settings) {
        NeuroSyncDB.updateSettings({
            reminders: true,
            updates: true,
            camera: true
        });
    }
};

// Utility function to format dates
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}